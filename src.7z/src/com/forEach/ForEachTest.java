package com.forEach;

import java.util.List;
import java.util.ArrayList;
import java.util.function.Consumer;

public class ForEachTest 
{
	public static void main (String [] s) 
	{
		System.out.println("Begin");
		List<Integer> integers = new ArrayList<>();
		for(int i=1;i<=10;i++)
		{
			integers.add(i);
		}
		
		integers.forEach((Integer i) -> System.out.println(i));
		integers.forEach((Integer i) -> {System.out.println(i);});
		
		Consumer<Integer> consumers = new Consumer<Integer> () {
			public void accept(Integer i)
			{
				System.out.println(i);
			}
		};
		consumers.accept(20);
		
		
	}
}